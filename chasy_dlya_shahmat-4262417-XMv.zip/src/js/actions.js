function switchTurn(player, context) {
    addAction({
        type: "switch_turn",
        player: player
    }, context);
}

function setTime(minutes, context) {
    addAction({
        type: "set_time",
        minutes: minutes
    }, context);
}

function togglePause(context) {
    addAction({
        type: "toggle_pause"
    }, context);
}

function startGame(context) {
    addAction({
        type: "start_game"
    }, context);
}
