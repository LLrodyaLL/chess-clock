// Извлечение исходного запроса из контекста
function get_request(context) {
    if (context && context.request) {
        return context.request.rawRequest;
    }
    return {};
}

function get_items(request){
if (request &&
        request.payload &&
        request.payload.meta &&
        request.payload.meta.current_app &&
        request.payload.meta.current_app.state &&
        request.payload.meta.current_app.state.item_selector){
        return request.payload.meta.current_app.state.item_selector.items;
    }
    return null;
}

// Извлечение текущего состояния игры из запроса
function get_game_state(request) {
    if (request && request.payload && request.payload.game_state) {
        return request.payload.game_state;
    }
    return null;
}

// Извлечение текущего игрока
function get_current_player(request) {
    var gameState = get_game_state(request);
    if (gameState) {
        return gameState.current_player;
    }
    return null;
}

// Извлечение оставшегося времени для игрока
function get_remaining_time(player, request) {
    var gameState = get_game_state(request);
    if (gameState && gameState.time) {
        return gameState.time[player];
    }
    return null;
}

// Извлечение состояния паузы
function get_is_paused(request) {
    var gameState = get_game_state(request);
    if (gameState) {
        return gameState.is_paused;
    }
    return false;
}