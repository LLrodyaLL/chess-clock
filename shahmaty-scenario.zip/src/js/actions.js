function switchTurn(player, context) {
    if (!getIsPaused()) {
        clearInterval(getTimer());
        if (player === 1) {
            setCurrentTurn(2);
        } else {
            setCurrentTurn(1);
        }
    }
}

function setTime(minutes, context) {
    setPlayer1Time(minutes * 60);
    setPlayer2Time(minutes * 60);
    clearInterval(getTimer());
    setCurrentTurn(0);
    setIsPaused(false);
}

function togglePause(context) {
    setIsPaused(!getIsPaused());
}
