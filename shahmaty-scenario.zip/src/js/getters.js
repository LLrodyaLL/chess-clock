var player1Time = 300; // 5 minutes in seconds
var player2Time = 300; // 5 minutes in seconds
var currentTurn = 0; // 0 means no one's turn, 1 means player 1's turn, 2 means player 2's turn
var timer = null;
var isPaused = false;

function getCurrentTurn() {
    return currentTurn;
}

function getIsPaused() {
    return isPaused;
}

function getTimer() {
    return timer;
}

function getPlayer1Time() {
    return player1Time;
}

function getPlayer2Time() {
    return player2Time;
}

function setCurrentTurn(turn) {
    currentTurn = turn;
}

function setTimer(newTimer) {
    timer = newTimer;
}

function setPlayer1Time(time) {
    player1Time = time;
}

function setPlayer2Time(time) {
    player2Time = time;
}

function setIsPaused(pause) {
    isPaused = pause;
}
